
OzFilterest<-function(x,nday,k)
{ 
  
  x=x
  
  mydatadate<-as.POSIXlt(x[,1])
  
  ndaymean=matrix(0,dim(x)[1]+1-nday )
  
  for(i in length(ndaymean):1)
  {   ndaymean[i]=mean(x[(i+nday-1):i,5])
  }
  
  locallow=ndaymean[1]
  localhigh=ndaymean[1]
  a=1 
  b=1 
  j=0
  r=data.frame(a = NA, b = NA)     
  buyind=0             
  sellind=0             
  
  buysell<-data.frame(a = NA, b = NA, c = NA, d= NA)  
  colnames(buysell)=c("buydate","buyprice","selldate","sellprice")
  ipoint<-data.frame(a = NA, b = NA)  
  colnames(ipoint)=c("i","price")
  for(i in 1:length(ndaymean))
  {   if(ndaymean[i]<locallow &&a==1 )  
  {  locallow=ndaymean[i]  
  }
      if( ndaymean[i]>(1+k)*locallow &&a==1 )  
      { 
        buyind=buyind+1 
        
        ipoint[buyind+sellind,1]=i+nday            
        ipoint[buyind+sellind,2]=x[i+nday,5]      
        
        buysell[buyind,1]=format(mydatadate[i+nday])   
        buysell[buyind,2]=format(x[i+nday,5],nsmall=2)            
        
        localhigh=ndaymean[i]    
        a=0                    
      }
      if(a==0 && ndaymean[i]>localhigh  )  
      {  localhigh=ndaymean[i]  
      }
      
      if(a==0 &&  ndaymean[i]<(1-k)*localhigh&&b==1 )  
      { 
        sellind=sellind+1
        
        ipoint[buyind+sellind,1]=i+nday            
        ipoint[buyind+sellind,2]=x[i+nday,5]    
        
        buysell[sellind,3]=format(mydatadate[i+nday])  
        buysell[sellind,4]=format(x[i+nday,5],nsmall=2)                   
        
        
        b=0                   
        j=j+1
        r[j,2]=( as.double(buysell[j,4]) *0.995575- as.double(buysell[j,2]) *1.001425)/(  as.double(buysell[j,2])  *1.001425)
        r[j,2]=round( r[j,2] ,4) 
        r[j,1]=as.numeric(substring(mydatadate[i+nday-1],first=1,last=4) ) 
        a=1
        b=1
        locallow=ndaymean[i]       
        localhigh=ndaymean[i]
      } 
  }

  

  list(ndaymean=ndaymean,
       buysell=buysell,
       r=r,
       ipoint=ipoint,      
       mydatadate=mydatadate, 
       x=x)   
  
}

OzFilter<-function(x,nday,k,...) UseMethod("OzFilter")
OzFilter.default<-function(x,nday=10,k=0.08,...)
{ 
  x<-x
  
  est<-OzFilterest(x,nday,k)
  
  class(est)<-"OzFilter"
  est
}

print.OzFilter<-function(x,...)  
{    
  buysell=x$buysell          
  
  if(is.na(buysell[1,2]))        
  {
    print("No Any Signal for Buy&Sell") 
    
  }
  
  else{
    print(x$buysell) 
  }
}

summary.OzFilter<-function(object,...)
{ 
  r=as.matrix(object$r)   
  
  if(length(r)==2)
  {  r=matrix(r,nrow=1,ncol=2)
     
  }   
  
  
  if(r[1,1]!=0)    
  {   
    if(nrow(r)==1)   
    {
      ACARR=r[1,2]
      res<-list(r=r,ACARR=ACARR)
      
    }else{
      
      rit<-matrix(0,nrow(r)+1,nrow(r))   
      year<-1  
      t<-1       
      rit[1,year]=r[1,1]
      rit[2,year]=r[1,2]
      
      for(d in 2:dim(r)[1])
      {   
        if(r[d,1]>r[d-1,1])    
        {  t=1
           year=year+1
           rit[1,year]=r[d,1]
           rit[t+1,year]=r[d,2]
        }   
        else if(r[d,1]==r[d-1,1])
        {                            
          t=t+1
          rit[t+1,year]=r[d,2]
        }
        
      }
      
      ritt<-matrix(0,dim(rit)[1]-1,nrow(r))    
      {   for(f in 1: dim(rit)[2] )
      {   ritt[e,f]=rit[e+1,f]+1
      } 
      }
      
      Ri<-matrix(0,2,nrow(r))
      for(e in 1:dim(rit)[2])                  
      {   if(rit[1,e]!=0)                         
      {  Ri[1,e]=rit[1,e]                      
         Ri[2,e]=prod( ritt[1:dim(ritt)[1],e]   )-1   
         
      }
      }
      Ri[2,]=round(Ri[2,],4)  

      ACARR=Ri[2,1]+1                
      for(e in 2:dim(Ri)[2])
      {   if(Ri[1,e]!=0)          
      {
        ACARR=ACARR*(Ri[2,e]+1)      
      }
      }
      ACARR=ACARR^(1/year)-1          
      ACARR=round(ACARR,4)
      
      res<-list(r=r,
                Ri=Ri,
                ACARR=ACARR)
    }
    
  }  else {  ACARR="NULL"            
             res<-list(r=r,ACARR=ACARR)
  }    
  
  class(res)<-"summary.OzFilter"
  res
  
}

print.summary.OzFilter<-function(x,...)
{   
  r=x$r 
  ACARR=x$ACARR
  
  
  if(r[1,1]!=0 && nrow(r)>1) 
  {   
    
    Ri=x$Ri
    
    cat("Return:\n")
    cat("Transaction Time(s)\t\t\tYear\t\t\t\tReturn\n")
    
    for(i in 1:dim(r)[1])
    {   if(r[i,1]>0)
    {  cat("\t\t",i,"\t\t\t",r[i,1],"\t",format(r[i,2],nsmall=4),"\n")      
    }
        
    }
    cat("\n")
    cat("Return per Year:\n")
    cat("Year\t\t\t\tReturn\n")
    for(i in 1:dim(Ri)[2])
    {   if(Ri[1,i]>0)
    {  cat(Ri[1,i],"\t",Ri[2,i],"\n")       
    }
    }
    cat("\n")
    cat("Averaged Compound Annual Rate of Return:\n")
    cat("ACARR:",ACARR)
  } else if(r[1,1]!=0 && nrow(r)==1)    
  {          
    cat("Return:\n")
    cat("Transaction Time(s)\t\t\tYear\t\t\t\tReturn\n")   
    cat("\t\t",1,"\t\t\t",r[1,1],"\t",format(r[1,2],nsmall=4),"\n")
    
    cat("\n")
    cat("Return per Year:\n")
    cat("Year\t\t\t\tReturn\n")
    cat(r[1,1],"\t",r[1,2],"\n")
    
    cat("\n")
    cat("Averaged Compound Annual Rate of Return:\n")
    cat("ACARR:",ACARR)
    
    
  } else{
    cat("ACARR: ",ACARR)
  }
  
}

plotFilter <- function(x, object,...)
{
  x = x
  buysell<-as.data.frame(rbind(object$buysell))
  
  if (colnames(x)[1] == 'Date') #determine date or mintue data
  {
    plot(x[ ,1], x[ ,5], type='l', xlab='Date', ylab='Close Price', las=2 ,main='' )
    lines(object$mydatadat,SMA(x[ ,5], n = Bestn), col='orangered2')
    points(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice),type = "p",col='red',pch=16)
    points(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice),type = "p",col='blue3',pch=17)
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice), adj = c(0.5,-1),labels='BUY',col='red')
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$buyprice)),col='red',font=2)
    text(as.POSIXlt(buysell$buydate,),as.numeric(buysell$buyprice), adj = c(0.5,3),labels=buysell$buydate,col='red')
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice), adj = c(0.5,-1),labels='SELL',col='blue3')
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$sellprice)),col='blue3',font=2)
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice), adj = c(0.5,3),labels=buysell$selldate,col='blue3')
  }else if (colnames(x)[1] == 'DateTime')
  {
    plot(x[ ,5], type='l', xlab='DateTime', ylab='Close Price', las=2, xaxt='n' ,main='' )
    atn <- seq(1, dim(x)[1], by=30) #set up axis gap
    x[atn, 1]
    axis(1,at=atn, labels=x[atn, 1],las=1,cex.axis=0.7)
    buypoint <- match(as.POSIXlt(buysell$buydate),x$DateTime) # match is used to find the rownumber
    sellpoint <- match(as.POSIXlt(buysell$selldate),x$DateTime) 
    mydatepoint <- match(as.POSIXlt(object$mydatadate),x$DateTime)
    lines(mydatepoint,SMA(x[ ,5], n = Bestn), col='orangered2')
    points(buypoint,as.numeric(buysell$buyprice),type = "p",col='red',pch=16)
    points(sellpoint,as.numeric(buysell$sellprice),type = "p",col='blue3',pch=17)
    text(buypoint,as.numeric(buysell$buyprice), adj = c(0.5,-1),labels='BUY',col='red')
    text(buypoint,as.numeric(buysell$buyprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$buyprice)),col='red',font=2)
    text(buypoint,as.numeric(buysell$buyprice), adj = c(0.5,3),labels=buysell$buydate,col='red')
    text(sellpoint,as.numeric(buysell$sellprice), adj = c(0.5,-1),labels='SELL',col='blue3')
    text(sellpoint,as.numeric(buysell$sellprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$sellprice)),col='blue3',font=2)
    text(sellpoint,as.numeric(buysell$sellprice), adj = c(0.5,3),labels=buysell$selldate,col='blue3')
  }else
    plot(x[ ,5], type='l')
}

OzMaest<-function(x,Sday,Lday)
{ 
  x=x
  
  mydatadate=as.POSIXlt(x[,1])
  
  x.xts=as.xts(x[,2:5],mydatadate)
  
  
  shortMA<-SMA(x[,5],Sday)
  longMA<-SMA(x[,5],Lday)
  
  shortMA[is.na(shortMA)] <- 0
  longMA[is.na(longMA)] <- 0
  
  
  a<-0   
  b<-0   
  
  buyind<-0
  sellind<-0
  buysell=data.frame(a = NA, b = NA, c = NA, d = NA) 
  colnames(buysell)=c("buydate","buyprice","selldate","sellprice")
  
  r=data.frame(a = NA, b = NA) 
  j=0
  ipoint<-data.frame(a = NA, b = NA)
  
  for(i in Lday:(dim(x)[1]-1) )   
  {
    
    if(a==0 && b==0 && (shortMA[i]>longMA[i]) )   
    {  
      buyind=buyind+1
      ipoint[buyind+sellind,1]=i+1           
      ipoint[buyind+sellind,2]=x[i+1,5]
      
      buysell[buyind,1]=format(mydatadate[i+1])   
      buysell[buyind,2]=format(x[i+1,5],nsmall=2)
      a=1                                       
    }  
    
    if(a==1 && b==0 && (shortMA[i]<longMA[i]) ) 
    {  sellind=sellind+1
       
       ipoint[buyind+sellind,1]=i+1           
       ipoint[buyind+sellind,2]=x[i+1,5]
       
       buysell[sellind,3]=format(mydatadate[i+1])
       buysell[sellind,4]=format(x[i+1,5],nsmall=2)
       b=1
       j=j+1
       r[j,2]=( as.double(buysell[j,4]) *0.995575- as.double(buysell[j,2]) *1.001425)/(  as.double(buysell[j,2])  *1.001425)
       r[j,2]=round( r[j,2] ,4) 
       r[j,1]=as.numeric(  substring(mydatadate[i],first=1,last=4) ) 
       a=0
       b=0
       
    }
  }
  
  shortMA<-SMA(x[,5],Sday)
  longMA<-SMA(x[,5],Lday)
  
  list(buysell=buysell,
       r=r,
       mydatadate=mydatadate,
       shortMA=shortMA,
       longMA=longMA,
       ipoint=ipoint,
       x=x)
  
}


OzMa<-function(x,Sday,Lday,...) UseMethod("OzMa")
OzMa.default<-function(x,Sday=10,Lday=30,...)
{ 
  x<-x
  
  
  est<-OzMaest(x,Sday,Lday)
  
  class(est)<-"OzMa"
  est
}

print.OzMa<-function(x,...)  
{    
  buysell=x$buysell        
  
  if(buysell[1,2]==0)       
  {
    print("No Any Signal for Buy&Sell!") 
  }
  
  else {
    
    print(x$buysell) 
  
  
  }
  
}


summary.OzMa<-function(object,...)
{ 
  r=as.matrix(object$r)   
  
  if(length(r)==2)
  {  r=matrix(r,nrow=1,ncol=2)
     
  }   
 
  
  
  if(r[1,1]!=0)    
  {   
    if(nrow(r)==1)    
    {
      ACARR=r[1,2]
      res<-list(r=r,ACARR=ACARR)
      
    }else{
      
      rit<-matrix(0,nrow(r)+1,nrow(r))
      year<-1   
      t<-1      
      rit[1,year]=r[1,1]
      rit[2,year]=r[1,2]
      
      for(d in 2:dim(r)[1])
      {   
        if(r[d,1]>r[d-1,1])     
        {  t=1
           year=year+1
           rit[1,year]=r[d,1]
           rit[t+1,year]=r[d,2]
        }   
        else if(r[d,1]==r[d-1,1])
        {                            
          t=t+1
          rit[t+1,year]=r[d,2]
        }
        
      }
      
      ritt<-matrix(0,dim(rit)[1]-1,nrow(r))    
      for(e in 1: dim(rit)[1]-1 )
      {   for(f in 1: dim(rit)[2] )
      {   ritt[e,f]=rit[e+1,f]+1
          
      }
      }
      
      Ri<-matrix(0,2,nrow(r))
      for(e in 1:dim(rit)[2])
      {   if(rit[1,e]!=0)
      {  Ri[1,e]=rit[1,e]
         Ri[2,e]=prod( ritt[1:dim(ritt)[1],e]   )-1
         
      }
      }
      
      Ri[2,]=round(Ri[2,],4)
      ACARR=Ri[2,1]+1                
      for(e in 2:dim(Ri)[2])
      {   if(Ri[1,e]!=0)          
      {
        ACARR=ACARR*(Ri[2,e]+1)      
      }
      }
      ACARR=ACARR^(1/year)-1          
      ACARR=round(ACARR,4)
      
      res<-list(r=r,
                Ri=Ri,
                ACARR=ACARR)
      
    }
  }  else {  ACARR="NULL"            
             res<-list(r=r,ACARR=ACARR)
  } 
  
  
  class(res)<-"summary.OzMa"
  res
  
}


print.summary.OzMa<-function(x,...)
{   r=x$r
    ACARR=x$ACARR
    
    
    if(r[1,1]!=0 && nrow(r)>1)  
    {
      Ri=x$Ri
      
      cat("Return:\n")
      cat("Transaction Time(s)\t\t\tYear\t\t\t\tReturn\n")
      
      for(i in 1:dim(r)[1])
      {   if(r[i,1]>0)
      {  cat("\t\t",i,"\t\t\t",r[i,1],"\t",format(r[i,2],nsmall=4),"\n")      
      }           
      }
      cat("\n")
      cat("Return per Year:\n")
      cat("Year\t\t\t\tReturn\n")
      for(i in 1:dim(Ri)[2])
      {   if(Ri[1,i]>0)
      {  cat(Ri[1,i],"\t",Ri[2,i],"\n")     
      } 
      }
      cat("\n")
      cat("Averaged Compound Annual Rate of Return:\n")
      cat("ACARR:",ACARR)
    } else if(r[1,1]!=0 && nrow(r)==1)   
    {          
      cat("Return:\n")
      cat("Transaction Time(s)\t\t\tYear\t\t\t\tReturn\n")   
      cat("\t\t",1,"\t\t\t",r[1,1],"\t",format(r[1,2],nsmall=4),"\n")
      
      cat("\n")
      cat("Return per Year:\n")
      cat("Year\t\t\t\tReturn\n")
      cat(r[1,1],"\t",r[1,2],"\n")
      
      cat("\n")
      cat("Averaged Compound Annual Rate of Return:\n")
      cat("ACARR:",ACARR)
      
      
    } else{
      cat("ACARR: ",ACARR)
    }
}

plotOzMa<-function(x, object,...)
{
  x = x
  buysell<-as.data.frame(rbind(object$buysell))
  
  if (colnames(x)[1] == 'Date') #determine date or mintue data
  {
    plot(x[ ,1],x[ ,5], type='l', xlab='Date', ylab='Close Price', main='' )
    lines(object$mydatadate,object$shortMA,col='orangered2')
    lines(object$mydatadate,object$longMA,col='royalblue')
    points(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice),type = "p",col='red',pch=16)
    points(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice),type = "p",col='blue3',pch=17)
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice), adj = c(0.5,-1),labels='BUY',col='red')
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$buyprice)),col='red',font=2)
    text(as.POSIXlt(buysell$buydate,),as.numeric(buysell$buyprice), adj = c(0.5,3),labels=buysell$buydate,col='red')
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice), adj = c(0.5,-1),labels='SELL',col='blue3')
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$sellprice)),col='blue3',font=2)
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice), adj = c(0.5,3),labels=buysell$selldate,col='blue3')
  }else if (colnames(x)[1] == 'DateTime')
  {
    plot(x[ ,5], type='l', xlab='DateTime', ylab='Close Price', las=2, xaxt='n' ,main='' )
    atn <- seq(1, dim(x)[1], by=30)
    x[atn, 1]
    axis(1,at=atn, labels=x[atn, 1],las=1,cex.axis=0.8)
    buypoint <- match(as.POSIXlt(buysell$buydate),x$DateTime) # match is used to find the rownumber
    sellpoint <- match(as.POSIXlt(buysell$selldate),x$DateTime) 
    mydatepoint <- match(as.POSIXlt(object$mydatadate),x$DateTime)
    lines(mydatepoint,object$shortMA,col='orangered2')
    lines(mydatepoint,object$longMA,col='royalblue')
    points(buypoint,as.numeric(buysell$buyprice),type = "p",col='red',pch=16)
    points(sellpoint,as.numeric(buysell$sellprice),type = "p",col='blue3',pch=17)
    text(buypoint,as.numeric(buysell$buyprice), adj = c(0.5,-1),labels='BUY',col='red')
    text(buypoint,as.numeric(buysell$buyprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$buyprice)),col='red',font=2)
    text(buypoint,as.numeric(buysell$buyprice), adj = c(0.5,3),labels=buysell$buydate,col='red')
    text(sellpoint,as.numeric(buysell$sellprice), adj = c(0.5,-1),labels='SELL',col='blue3')
    text(sellpoint,as.numeric(buysell$sellprice), adj = c(0.5,1.5),labels=as.numeric(as.character(buysell$sellprice)),col='blue3',font=2)
    text(sellpoint,as.numeric(buysell$sellprice), adj = c(0.5,3),labels=buysell$selldate,col='blue3')
  } else
    plot(x[ ,5], type='l')
  
}

OzRsiest<-function(x,Sday,Lday)
{ 
  x=x
  
  mydatadate=as.POSIXlt(x[,1])
  
  x.xts=as.xts(x[,2:5],mydatadate)
  
  
  shortRSI<-RSI(x[,5],Sday,maType="EMA")
  longRSI<-RSI(x[,5],Lday,maType="EMA")
  
  
  a<-0   
  b<-0  
  
  buyind<-0
  sellind<-0
  buysell=data.frame(a = NA, b = NA, c = NA, d = NA) 
  colnames(buysell)=c("buydate","buyprice","selldate","sellprice")
  
  r=data.frame(a = NA, b = NA) 
  j=0
  ipoint<-data.frame(a = NA, b = NA) 
  for(i in (Lday+1):(dim(x)[1]-3)  )   
  {
    if(a==0 && b==0 && shortRSI[i]>longRSI[i] && shortRSI[i]>50 && shortRSI[i+1]>50 & shortRSI[i+2]>50 & shortRSI[i+3]>50)   
    {  
      buyind=buyind+1
      ipoint[buyind+sellind,1]=i+3           
      ipoint[buyind+sellind,2]=x[i+3,5]
      
      buysell[buyind,1]=format(mydatadate[i+3])  
      buysell[buyind,2]=format(x[i+3,5],nsmall=2)
      a=1                                       
    }  
    
    if(a==1 && b==0 && shortRSI[i]<longRSI[i]&& shortRSI[i]<50 && shortRSI[i+1]<50 & shortRSI[i+2]<50 & shortRSI[i+3]<50 )  
    {  sellind=sellind+1
       
       ipoint[buyind+sellind,1]=i+3           
       ipoint[buyind+sellind,2]=x[i+3,5]
       
       buysell[sellind,3]=format(mydatadate[i+3])
       buysell[sellind,4]=format(x[i+3,5],nsmall=2)
       b=1
       j=j+1
       r[j,2]=( as.double(buysell[j,4]) *0.995575- as.double(buysell[j,2]) *1.001425)/(  as.double(buysell[j,2])  *1.001425)
       r[j,2]=round( r[j,2] ,4)  
       r[j,1]=as.numeric(  substring(mydatadate[i],first=1,last=4) ) 
       a=0
       b=0
       
    }
  }
  
  list(buysell=buysell,
       r=r,
       mydatadate=mydatadate,
       shortRSI=shortRSI,
       longRSI=longRSI,
       ipoint=ipoint,
       x=x)
  
}

OzRsi<-function(x,Sday,Lday,...) UseMethod("OzRsi")
OzRsi.default<-function(x,Sday=6,Lday=12,...)
{ 
  x<-x
  
  est<-OzRsiest(x,Sday,Lday)
  
  class(est)<-"OzRsi"
  est
}


print.OzRsi<-function(x,...)  
{    
  buysell=x$buysell          
  
  if(is.na(buysell[1,2]))      
  {
    print("No Any Signal for Buy&Sell!") 
    
  } 
  else {
    print(x$buysell) 
  }
  
}


summary.OzRsi<-function(object,...)
{ 
  r=as.matrix(object$r)   
  
  if(length(r)==2)
  {  r=matrix(r,nrow=1,ncol=2)
     
  }   
  
  if(r[1,1]!=0)    
  {   
    if(nrow(r)==1)    
    {
      ACARR=r[1,2]
      res<-list(r=r,ACARR=ACARR)
      
    }else{###
      
      rit<-matrix(0,nrow(r)+1,nrow(r))
      year<-1    
      t<-1      
      rit[1,year]=r[1,1]
      rit[2,year]=r[1,2]
      
      for(d in 2:dim(r)[1])
      {   
        if(r[d,1]>r[d-1,1])     
        {  t=1
           year=year+1
           rit[1,year]=r[d,1]
           rit[t+1,year]=r[d,2]
        }   
        else if(r[d,1]==r[d-1,1])
        {                            
          t=t+1
          rit[t+1,year]=r[d,2]
        }
        
      }
      
      ritt<-matrix(0,dim(rit)[1]-1,nrow(r))    
      for(e in 1: dim(rit)[1]-1 )
      {   for(f in 1: dim(rit)[2] )
      {   ritt[e,f]=rit[e+1,f]+1
          
      }
      }
      
      Ri<-matrix(0,2,nrow(r))
      for(e in 1:dim(rit)[2])
      {   if(rit[1,e]!=0)
      {  Ri[1,e]=rit[1,e]
         Ri[2,e]=prod( ritt[1:dim(ritt)[1],e]   )-1
         
      }
      }
      
      Ri[2,]=round(Ri[2,],4)
      
      ACARR=Ri[2,1]+1                 
      for(e in 2:dim(Ri)[2])
      {   if(Ri[1,e]!=0)          
      {
        ACARR=ACARR*(Ri[2,e]+1)      
      }
      }
      ACARR=ACARR^(1/year)-1          
      ACARR=round(ACARR,4)
      
      res<-list(r=r,
                Ri=Ri,
                ACARR=ACARR)
      
    }
  }  else {  ACARR="NULL"               
             res<-list(r=r,ACARR=ACARR)
  } 
  
  
  class(res)<-"summary.OzRsi"
  res
  
}

print.summary.OzRsi<-function(x,...)
{   r=x$r
    ACARR=x$ACARR
    
    
    if(r[1,1]!=0 && nrow(r)>1)  
    {
      Ri=x$Ri
      
      cat("Return:\n")
      cat("Transaction\t\t\tYear\t\t\t\tReturn\n")
      
      for(i in 1:dim(r)[1])
      {   if(r[i,1]>0)
      {  cat("\t\t",i,"\t\t\t",r[i,1],"\t",format(r[i,2],nsmall=4),"\n")      
      }           
      }
      cat("\n")
      cat("Return per Year:\n")
      cat("Year\t\t\t\tReturn\n")
      for(i in 1:dim(Ri)[2])
      {   if(Ri[1,i]>0)
      {  cat(Ri[1,i],"\t",Ri[2,i],"\n")     
      } 
      }
      cat("\n")
      cat("Averaged Compound Annual Rate of Return:\n")
      cat("ACARR:",ACARR)
    } else if(r[1,1]!=0 && nrow(r)==1)    
    {          
      cat("Return:\n")
      cat("Transaction Time(s)\t\t\tYear\t\t\t\tReturn\n")   
      cat("\t\t",1,"\t\t\t",r[1,1],"\t",format(r[1,2],nsmall=4),"\n")
      
      cat("\n")
      cat("Return per Year:\n")
      cat("Year\t\t\t\tReturn\n")
      cat(r[1,1],"\t",r[1,2],"\n")
      
      cat("\n")
      cat("Averaged Compound Annual Rate of Return:\n")
      cat("ACARR:",ACARR)
      
      
    } else{
      cat("ACARR: ",ACARR)
    }
}

plotRSI <- function(x, object,...)
{
  x = x
  buysell<-as.data.frame(rbind(object$buysell))
  
  if (colnames(x)[1] == 'Date') #determine date or mintue data
  {
    mat <- matrix(c(1,2), nrow=2, ncol=1) #martix for 1*2 plot
    layout(mat, heights= c(3,1)) #set up the size of plot
    par(mar=c(2,4,1.5,1))
    plot(x[ ,1],x[ ,5], type='l', xlab='Date', ylab='Close Price', main='', lwd = 1.5, lend = "round", ljoin = "round")
    points(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice),type = "p",col='red',pch=16)
    points(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice),type = "p",col='blue3',pch=17)
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice),adj = c(0.5,-1),labels='BUY',col='red')
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice),adj = c(0.5,1.5),labels=as.numeric(buysell$buyprice),col='red',font=2)
    text(as.POSIXlt(buysell$buydate),as.numeric(buysell$buyprice),adj = c(0.5,3),labels=buysell$buydate,col='red')
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice),adj = c(0.5,-1),labels='SELL',col='blue3')
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice),adj = c(0.5,1.5),labels=as.numeric(buysell$sellprice),col='blue3',font=2)
    text(as.POSIXlt(buysell$selldate),as.numeric(buysell$sellprice),adj = c(0.5,3),labels=buysell$selldate,col='blue3')
    plot(object$mydatadate, object$shortRSI, xlab='Date', ylab='RSI', type = "l",col='tomato', lwd = 2, lend = "round", ljoin = "round")
    lines(object$mydatadate, object$longRSI, col = 'mediumseagreen', lwd = 2, lend = "round", ljoin = "round")
    abline(h = 50, col = 'grey51')    
  }else if (colnames(x)[1] == 'DateTime')
  {
    mat <- matrix(c(1,2), nrow=2, ncol=1) #martix for 1*2 plot
    layout(mat, heights= c(3,1)) #set up the size of plot
    par(mar=c(2,4,1.5,1))
    plot(x[ ,5], type='l', xlab='', ylab='Close Price', main='', lwd = 1.5, lend = "round", ljoin = "round", xaxt='n')
    atn <- seq(1, dim(x)[1], by=30) #set up axis gap
    x[atn, 1]
    axis(1,at=atn, labels=x[atn, 1],las=1,cex.axis=1)
    buypoint <- match(as.POSIXlt(buysell$buydate),x$DateTime) # match is used to find the rownumber
    sellpoint <- match(as.POSIXlt(buysell$selldate),x$DateTime) 
    mydatepoint <- match(as.POSIXlt(object$mydatadate),x$DateTime)
    points(buypoint,as.numeric(buysell$buyprice),type = "p",col='red',pch=16)
    points(sellpoint,as.numeric(buysell$sellprice),type = "p",col='blue3',pch=17)
    text(buypoint,as.numeric(buysell$buyprice),adj = c(0.5,-1),labels='BUY',col='red')
    text(buypoint,as.numeric(buysell$buyprice),adj = c(0.5,1.5),labels=as.numeric(buysell$buyprice),col='red',font=2)
    text(buypoint,as.numeric(buysell$buyprice),adj = c(0.5,3),labels=buysell$buydate,col='red')
    text(sellpoint,as.numeric(buysell$sellprice),adj = c(0.5,-1),labels='SELL',col='blue3')
    text(sellpoint,as.numeric(buysell$sellprice),adj = c(0.5,1.5),labels=as.numeric(buysell$sellprice),col='blue3',font=2)
    text(sellpoint,as.numeric(buysell$sellprice),adj = c(0.5,3),labels=buysell$selldate,col='blue3')
    plot(mydatepoint, object$shortRSI, xlab='Date', ylab='RSI', type = "l",col='tomato', lwd = 2, lend = "round", ljoin = "round", xaxt='n')
    atn <- seq(1, dim(x)[1], by=30) #set up axis gap
    axis(1,at=atn, labels=x[atn, 1],las=1,cex.axis=1)
    lines(mydatepoint, object$longRSI, col = 'mediumseagreen', lwd = 2, lend = "round", ljoin = "round")
    abline(h = 50, col = 'grey51')
  }else
    plot(x[ ,5], type='l')
}
